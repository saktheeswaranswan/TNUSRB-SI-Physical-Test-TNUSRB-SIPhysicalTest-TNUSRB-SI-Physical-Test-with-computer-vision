Node Number,Node Name
0,Wrist
1,Thumb metacarpal
2,Thumb proximal phalanx
3,Thumb distal phalanx
4,Thumb tip
5,Index finger metacarpal
6,Index finger proximal phalanx
7,Index finger middle phalanx
8,Index finger distal phalanx
9,Index finger tip
10,Middle finger metacarpal
11,Middle finger proximal phalanx
12,Middle finger middle phalanx
13,Middle finger distal phalanx
14,Middle finger tip
15,Ring finger metacarpal
16,Ring finger proximal phalanx
17,Ring finger middle phalanx
18,Ring finger distal phalanx
19,Ring finger tip
20,Pinky finger metacarpal
21,Pinky finger proximal phalanx
22,Pinky finger middle phalanx
23,Pinky finger distal phalanx
24,Pinky finger tip

